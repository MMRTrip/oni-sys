function oni-backup --description 'Oni-Sys Local Config Backup'
    set -l c_red (set_color -o red)
    set -l c_mag (set_color -o magenta)
    set -l c_dark (set_color brblack)
    set -l c_reset (set_color normal)

    # Создаем папку для бэкапов в домашней директории, если её нет
    set -l backup_dir ~/Oni-Sys-Backups
    mkdir -p $backup_dir

    # Имя архива с текущей датой
    set -l date_str (date +%Y-%m-%d_%H-%M)
    set -l archive_name "$backup_dir/oni_backup_$date_str.tar.gz"

    echo "$c_mag"[Oni-Sys]"$c_reset Начинаю сбор кастомных конфигов демона..."

    # Создаем временную папку для структуры
    set -l tmp_dir (mktemp -d)
    mkdir -p $tmp_dir/fish/functions
    mkdir -p $tmp_dir/starship

    # 1. Копируем конфиги Fish и наши функции
    cp ~/.config/fish/config.fish $tmp_dir/fish/
    cp ~/.config/fish/functions/oni-*.fish $tmp_dir/fish/functions/

    # 2. Копируем конфиги Starship (все вариации)
    cp ~/.config/starship*.toml $tmp_dir/starship/ 2>/dev/null

    # Упаковываем всё это добро в архив
    cd $tmp_dir
    if tar -czf $archive_name .
        echo "$c_mag"[Успех]"$c_reset Архив создан: $archive_name"
        notify-send "Oni-Sys Backup" "Бэкап успешно создан локально!" --icon=document-save
    else
        echo "$c_red"[Ошибка]"$c_reset Не удалось создать архив."
        notify-send "Oni-Sys Backup" "Ошибка при создании бэкапа!" --icon=dialog-error
    end

    # Чистим за собой временную папку
    cd -
    rm -rf $tmp_dir
end
